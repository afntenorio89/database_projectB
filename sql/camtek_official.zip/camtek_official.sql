-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 26, 2018 at 04:35 AM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `camtek_official`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `order_lotNumber` varchar(20) NOT NULL,
  `product_number` varchar(20) DEFAULT 'NA',
  `order_description` varchar(256) DEFAULT 'NA',
  `order_quantity` int(11) DEFAULT '0',
  `order_assignedBy` varchar(20) NOT NULL,
  `order_assignedDate` varchar(20) DEFAULT 'NA',
  `order_status` varchar(50) DEFAULT 'NA',
  `order_comment` varchar(256) DEFAULT 'NA',
  PRIMARY KEY (`order_lotNumber`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `parts`
--

DROP TABLE IF EXISTS `parts`;
CREATE TABLE IF NOT EXISTS `parts` (
  `part_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` varchar(20) NOT NULL,
  `part_number` varchar(20) NOT NULL,
  `part_name` varchar(50) DEFAULT 'NA',
  `part_primaryLocation` varchar(50) DEFAULT 'NA',
  `part_secondaryLocation` varchar(50) DEFAULT 'NA',
  `part_cleanroomLocation` varchar(50) DEFAULT 'NA',
  `part_quantity` float DEFAULT '0',
  `part_secondaryQuantity` float DEFAULT '0',
  `part_cleanroomQuantity` float DEFAULT '0',
  `part_unitOfMeasurement` varchar(20) DEFAULT 'NA',
  `part_expirationDate` varchar(20) DEFAULT 'NA',
  `part_comment` varchar(256) DEFAULT 'NA',
  `part_hazardous` varchar(11) DEFAULT 'NA',
  `part_cers` varchar(11) DEFAULT 'NA',
  `part_msds` varchar(11) DEFAULT 'NA',
  `part_flamability` varchar(50) DEFAULT 'NA',
  `part_instability` varchar(50) DEFAULT 'NA',
  `part_health` varchar(50) DEFAULT 'NA',
  `part_specificHazard` varchar(50) DEFAULT 'NA',
  PRIMARY KEY (`part_id`,`project_id`,`part_number`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `partslist`
--

DROP TABLE IF EXISTS `partslist`;
CREATE TABLE IF NOT EXISTS `partslist` (
  `partslist_id` varchar(11) NOT NULL,
  `project_id` varchar(20) DEFAULT 'NA',
  `part_number` varchar(20) DEFAULT 'NA',
  `partslist_qty` int(11) DEFAULT '0',
  `partslist_comment` varchar(256) DEFAULT 'NA',
  PRIMARY KEY (`partslist_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `project_id` varchar(20) NOT NULL,
  `product_number` varchar(20) NOT NULL,
  `product_name` varchar(50) DEFAULT 'NA',
  `product_description` varchar(100) DEFAULT 'NA',
  `product_supplier` varchar(20) DEFAULT 'NA',
  `partsList_id` varchar(20) DEFAULT 'NA',
  `product_leadTime` varchar(50) DEFAULT 'NA',
  `product_refDWG` varchar(50) DEFAULT 'NA',
  `product_refMP` varchar(50) DEFAULT 'NA',
  PRIMARY KEY (`product_number`),
  KEY `projectid` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
CREATE TABLE IF NOT EXISTS `projects` (
  `project_id` varchar(20) NOT NULL,
  `project_name` varchar(50) NOT NULL,
  `project_description` varchar(100) DEFAULT 'NA',
  `project_lead` varchar(20) DEFAULT 'NA',
  `project_members` varchar(100) DEFAULT 'NA',
  `project_comment` varchar(256) DEFAULT 'NA',
  `project_status` varchar(20) DEFAULT 'NA',
  PRIMARY KEY (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_firstname` varchar(20) NOT NULL,
  `user_lastname` varchar(20) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `user_password` varchar(256) NOT NULL,
  `user_initials` varchar(11) NOT NULL,
  `user_permission` enum('pending','approved','admin') NOT NULL DEFAULT 'pending',
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_firstname`, `user_lastname`, `user_email`, `user_name`, `user_password`, `user_initials`, `user_permission`) VALUES
(8, 'Anthony', 'Tenorio', 'afntenoio89@yahoo.com', 'atenorio', '$2y$10$vc8nW/Wa2PXhiLxOr6Yt7uYl.uJMOEdekWs5fRU9yRj4XZJ6VoOwi', 'AT', 'pending');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
